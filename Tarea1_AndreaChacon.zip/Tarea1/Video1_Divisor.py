#Ejercicio 4
print("Digite un numero")
numero=int(input("Numero:"))

while numero>0:
    Suma=0
    for i in range(1,numero+1):
        if(numero% i==0):
            Suma=Suma + i
    print (Suma)
    numero=int(input("Numero:"))

# 1+2+5+10=18